<?php
$con = mysqli_connect('localhost','root');
if($con){
}else{
	echo " no connection"; 
}
?>