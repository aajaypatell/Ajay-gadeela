<?php
$_session['user']='asdldjfkxdfdf123456';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/seat_select.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <form action="checkout.php" method="post">
    <div style="position:fixed;left:350px">
        <form name="selection" method="post" action="avenger_process.php">
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="A1">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="A2">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="A3">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="A4">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="A5">
                <i class="fa fa-ticket" style="margin-left: 50px;"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="A6">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="A7">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="A8">
                <i class="fa fa-ticket"></i>
            </label>
            <br>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="B1">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="B2">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="B3">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="B4">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="B5">
                <i class="fa fa-ticket" style="margin-left: 50px;"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="B6">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="B7">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="B8">
                <i class="fa fa-ticket"></i>
            </label>
            <br>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="C1">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="C2">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="C3">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="C4">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="C5">
                <i class="fa fa-ticket" style="margin-left: 50px;"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="C6">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="C7">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="C8">
                <i class="fa fa-ticket"></i>
            </label>
            <br>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="D1">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="D2">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="D3">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="D4">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="D5">
                <i class="fa fa-ticket" style="margin-left: 50px;"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="D6">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="D7">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="D8">
                <i class="fa fa-ticket"></i>
            </label>
            <br>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="E1">
                <i class="fa fa-ticket" style="margin-top: 50px;"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="E2">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="E3">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="E4">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="E5">
                <i class="fa fa-ticket" style="margin-left: 50px;"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="E6">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="E7">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="E8">
                <i class="fa fa-ticket"></i>
            </label>
            <br>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="F1">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="F2">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="F3">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="F4">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="F5">
                <i class="fa fa-ticket" style="margin-left: 50px;"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="F6">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="F7">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="F8">
                <i class="fa fa-ticket"></i>
            </label>
            <br>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="G1">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="G2">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="G3">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="G4">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="G5">
                <i class="fa fa-ticket" style="margin-left: 50px;"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="G6">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="G7">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="G8">
                <i class="fa fa-ticket"></i>
            </label>
            <br>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="H1">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="H2">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="H3">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="H4">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="H5">
                <i class="fa fa-ticket" style="margin-left: 50px;"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="H6">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="H7">
                <i class="fa fa-ticket"></i>
            </label>
            <label class="toggle-button">
                <input type="checkbox" name="seat[]" value="H8">
                <i class="fa fa-ticket"></i>
            </label>
            <br>
            <div style="position:absolute;left:250px">
                <input type="submit" name="submit" value="Pay Now">
            </div>
        </form>
    </div>
    </form>
</body>
</html>
