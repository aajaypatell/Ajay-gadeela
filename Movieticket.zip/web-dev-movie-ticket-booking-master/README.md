# web-dev-movie-ticket-booking
A website where users can login and book the movie tickets online, the special feature is - site offers 3D preview that will help user to select a best seat from available ones







SCREENSHOTS

1. HOME PAGE (It is a carousal of images of 3 films)

![home](https://user-images.githubusercontent.com/53445466/69403605-fba17b00-0d20-11ea-82bd-036a25ae4271.png)


2. TOP MOVIES PAGE

Movies are categorized with respect to theaters by location
![topmovies](https://user-images.githubusercontent.com/53445466/69403724-563ad700-0d21-11ea-87e4-a582dfe9c7a9.png)

3. CONTACT US PAGE

![contactus](https://user-images.githubusercontent.com/53445466/69403885-c2b5d600-0d21-11ea-97ac-3de535d9b87e.png)

4. LOGIN PAGE

![loginmovie](https://user-images.githubusercontent.com/53445466/69403913-d5c8a600-0d21-11ea-8bab-b41f766089b8.png)

5. SIGNUP PAGE

![signupmovie](https://user-images.githubusercontent.com/53445466/69403917-d8c39680-0d21-11ea-90c5-a2218d26d6d9.png)


6. PREVIEW PAGE 

When user clicks on book now button on "top movies" page
this page will pe opened
![preview](https://user-images.githubusercontent.com/53445466/69403980-0577ae00-0d22-11ea-8f75-0daf2eebb0df.png)
User can select a seat from seat plan tray and the preview will be shown from selected seat from that seat position and relative view
of theater will be shown 180 degree view
PS: this page is just for seat preview for booking the selected seat from seat preview user can click on "select seat" Button

7. SELECT SEAT PAGE

![block](https://user-images.githubusercontent.com/53445466/69404264-df064280-0d22-11ea-916c-d59b9a084e7e.png)
the seats will glow once clicked on them, also seats already booked by other users will not glow
PS: color scheme is not mentioned so user will understand the status of seat only after seat is clicked


Once number of seats are selected, user will be taken to payment gateway (here Paytm) and can complete the payment process to confirm the booking


HAPPY BLOCKING!
